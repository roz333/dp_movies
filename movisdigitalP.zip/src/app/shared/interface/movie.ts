export interface Movie {
    id?: number;
    Title: string;
    Year: string;
    Genre: string;
    Director: string;
    Language: string;
    Released: string;
    }

